You are partially successful.

Now all you have to do is to get all the second letters for answers to clues Level 1 - Level 15 [Use first, in case there is not second]

Armed with this, you can solve your problem of finding the Emails.